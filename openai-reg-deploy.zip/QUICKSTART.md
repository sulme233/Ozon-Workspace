# 一键部署命令 (复制到 Ubuntu 执行)

## 方式1: 本地文件上传后部署

```bash
# 1. 上传所有文件到服务器
scp -r ./openai-reg-deploy/* user@your-server:~/openai-reg/

# 2. SSH 登录服务器执行
ssh user@your-server
cd ~/openai-reg
chmod +x deploy.sh
./deploy.sh
```

## 方式2: 直接下载部署 (如果文件在网盘)

```bash
# 创建目录
mkdir -p ~/openai-reg && cd ~/openai-reg

# 下载文件 (替换为实际链接)
wget -O gpt.py "YOUR_FILE_URL"
wget -O .env "YOUR_ENV_URL"
wget -O requirements.txt "YOUR_REQ_URL"

# 安装依赖并运行
pip3 install -r requirements.txt
nano .env  # 编辑配置
python3 gpt.py --count 1 --threads 1
```

## 方式3: Docker 部署 (推荐)

```bash
# 创建 Dockerfile
cat > Dockerfile << 'EOF'
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY gpt.py .
COPY .env .

CMD ["python3", "gpt.py", "--count", "999", "--threads", "5"]
EOF

# 构建并运行
docker build -t openai-reg .
docker run -d --name reg-bot \
  -v $(pwd)/tokens:/app/tokens \
  -v $(pwd)/auths:/app/auths \
  openai-reg

# 查看日志
docker logs -f reg-bot
```

## Systemd 服务管理

```bash
# 启动
systemctl --user start openai-reg

# 停止
systemctl --user stop openai-reg

# 重启
systemctl --user restart openai-reg

# 查看状态
systemctl --user status openai-reg

# 开机自启
systemctl --user enable openai-reg

# 禁用开机自启
systemctl --user disable openai-reg

# 查看日志
journalctl --user -u openai-reg -f
journalctl --user -u openai-reg --since "1 hour ago"
```

## 常用命令

```bash
# 快速测试
cd ~/openai-reg && python3 gpt.py --count 1 --threads 1

# 批量注册 50 个
cd ~/openai-reg && python3 gpt.py --count 50 --threads 10

# 检测已有 token
cd ~/openai-reg && python3 gpt.py --check

# 查看结果
ls -la ~/openai-reg/tokens/
cat ~/openai-reg/tokens/accounts.txt
```
