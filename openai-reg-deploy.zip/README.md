# OpenAI Auto-Registrar - Ubuntu 部署指南

## 📦 快速开始

### 1. 上传文件到 Ubuntu 服务器

```bash
# 在你的 Ubuntu 服务器上执行
mkdir -p ~/openai-reg && cd ~/openai-reg

# 然后上传以下文件:
# - gpt.py (核心脚本)
# - .env (配置文件)
# - requirements.txt
# - deploy.sh (一键部署脚本)
```

### 2. 一键部署

```bash
chmod +x deploy.sh
./deploy.sh
```

### 3. 手动配置

编辑配置文件：

```bash
nano ~/.env
```

**必填项：**
- `LUCKMAIL_API_KEY` - 从 https://mails.luckyous.com 获取

### 4. 添加代理

```bash
nano proxies.txt
```

格式：
```
http://user:pass@ip:port
http://ip:port
socks5://ip:port
```

### 5. 运行

**单次测试：**
```bash
cd ~/openai-reg
python3 gpt.py --count 1 --threads 1
```

**批量注册 (前台)：**
```bash
python3 gpt.py --count 100 --threads 10 --sleep-min 3 --sleep-max 8
```

**后台运行 (Systemd)：**
```bash
systemctl --user enable openai-reg
systemctl --user start openai-reg
journalctl --user -u openai-reg -f
```

---

## ⚙️ 配置说明

### 邮箱模式

| 模式 | 说明 | 适用场景 |
|------|------|----------|
| `luckmail` | 自动购买/使用已购邮箱 | **推荐**，最稳定 |
| `file` | 从文件读取邮箱列表 | 已有邮箱 |
| `cf` | Cloudflare Worker | 自建邮箱服务 |
| `hotmail007` | Hotmail007 API | 备选 |

### 关键参数

```bash
--count N          # 注册 N 个账号
--threads N        # N 线程并发
--sleep-min N      # 最小间隔秒数
--sleep-max N      # 最大间隔秒数
--proxy URL        # 单个代理
--proxy-file FILE  # 代理列表文件
```

---

## 📁 文件结构

```
~/openai-reg/
├── gpt.py              # 核心脚本
├── .env                # 配置文件
├── requirements.txt    # Python 依赖
├── proxies.txt         # 代理列表
├── tokens/             # 生成的 token
│   └── accounts.txt    # 账号密码
└── auths/              # CLI auths 目录
    └── codex-xxx.json  # 单个 token
```

---

## 🔧 常见问题

### 1. 依赖安装失败

```bash
# 升级 pip
pip3 install --upgrade pip

# 安装编译依赖
sudo apt install -y python3-dev build-essential
```

### 2. 代理问题

```bash
# 测试代理
curl -x http://ip:port https://cloudflare.com/cdn-cgi/trace

# 检查 IP 所在地
curl -s https://cloudflare.com/cdn-cgi/trace | grep loc
```

### 3. 权限问题

```bash
# 确保脚本可执行
chmod +x deploy.sh

# 修复权限
chmod -R 755 ~/openai-reg
```

### 4. 查看日志

```bash
# 前台运行日志
python3 gpt.py --count 1 2>&1 | tee run.log

# Systemd 日志
journalctl --user -u openai-reg -f
```

---

## 🚀 高级用法

### 检测已有 token 状态

```bash
python3 gpt.py --check
```

### 只使用已购邮箱（不购买新邮箱）

```bash
python3 gpt.py --luckmail-purchased-only
```

### 自定义邮箱类型

```bash
python3 gpt.py --luckmail-email-type ms_graph
```

---

## 📊 监控

```bash
# 查看成功数量
ls ~/openai-reg/tokens/*.json | wc -l

# 实时查看
watch -n 5 'ls ~/openai-reg/tokens/*.json 2>/dev/null | wc -l'

# 查看账号列表
cat ~/openai-reg/tokens/accounts.txt
```

---

## ⚠️ 注意事项

1. **代理必须可用** - 脚本会检查 IP 所在地，CN/HK 会报错
2. **LuckMail 余额** - 确保账户有足够余额购买邮箱
3. **并发数建议** - 根据代理质量和服务器配置调整，一般 5-20 线程
4. **间隔时间** - 建议 3-10 秒，避免触发风控

---

## 📞 支持

- LuckMail: https://mails.luckyous.com
- QQ群: 382446
