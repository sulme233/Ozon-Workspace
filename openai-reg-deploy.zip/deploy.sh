#!/bin/bash
#===============================================
# OpenAI 自动注册脚本 - Ubuntu 一键部署
# 使用 LuckMail 邮箱模式
#===============================================

set -e

echo "========================================="
echo "  OpenAI Auto-Registrar Ubuntu 部署"
echo "========================================="

# 1. 检查系统
echo "[1/6] 检查系统环境..."
if ! command -v python3 &>/dev/null; then
    echo "❌ 未安装 Python3，正在安装..."
    apt update && apt install -y python3 python3-pip git
else
    echo "✓ Python3 已安装: $(python3 --version)"
fi

# 2. 安装依赖
echo "[2/6] 安装 Python 依赖..."
pip3 install -r requirements.txt

# 3. 创建工作目录
echo "[3/6] 创建工作目录..."
WORK_DIR="$HOME/openai-reg"
mkdir -p "$WORK_DIR/tokens"
mkdir -p "$WORK_DIR/auths"

# 4. 配置文件
echo "[4/6] 配置环境变量..."
if [ ! -f "$WORK_DIR/.env" ]; then
    cat > "$WORK_DIR/.env" << 'EOF'
# ========= 核心配置 =========
# 邮箱模式: file / cf / hotmail007 / luckmail
EMAIL_MODE=luckmail

# LuckMail API Key (从 https://mails.luckyous.com 获取)
LUCKMAIL_API_KEY=your_api_key_here

# LuckMail API 地址 (一般不需要改)
LUCKMAIL_API_URL=https://mails.luckyous.com/api/v1/openapi

# 是否自动购买邮箱 (true/false)
LUCKMAIL_AUTO_BUY=true

# 已购模式: true=只使用已购邮箱, false=自动购买新邮箱
LUCKMAIL_PURCHASED_ONLY=false

# 邮箱类型: ms_graph / ms_imap
LUCKMAIL_EMAIL_TYPE=ms_imap

# Token 输出目录
TOKEN_OUTPUT_DIR=./tokens

# CLI auths 目录 (填你实际的)
CLI_PROXY_AUTHS_DIR=./auths

# ========= 代理配置 =========
# 代理文件路径 (每行一个代理，格式: http://ip:port)
PROXY_FILE=proxies.txt

# 单个代理 (优先使用文件)
# PROXY=http://127.0.0.1:7890

# ========= 批量配置 =========
# 批量注册数量
BATCH_COUNT=10

# 并发线程数
BATCH_THREADS=5

# 每次注册间隔 (秒)
SLEEP_MIN=3
SLEEP_MAX=8
EOF
    echo "✓ 已创建配置文件: $WORK_DIR/.env"
    echo "⚠️  请编辑 $WORK_DIR/.env 填入你的 LuckMail API Key"
else
    echo "✓ 配置文件已存在"
fi

# 5. 复制核心脚本
echo "[5/6] 复制核心脚本..."
if [ -f "$(dirname "$0")/gpt.py" ]; then
    cp "$(dirname "$0")/gpt.py" "$WORK_DIR/"
fi
cp "$(dirname "$0")/.env" "$WORK_DIR/" 2>/dev/null || true

# 6. 创建 Systemd 服务
echo "[6/6] 创建 Systemd 服务..."
SERVICE_FILE="$HOME/.config/systemd/user/openai-reg.service"
mkdir -p "$(dirname "$SERVICE_FILE")"

cat > "$SERVICE_FILE" << EOF
[Unit]
Description=OpenAI Auto-Registrar
After=network.target

[Service]
Type=simple
WorkingDirectory=$WORK_DIR
ExecStart=/usr/bin/python3 $WORK_DIR/gpt.py --count 999 --threads 5 --sleep-min 3 --sleep-max 8
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
EOF

echo "✓ Systemd 服务已创建: $SERVICE_FILE"
echo ""
echo "========================================="
echo "  部署完成！"
echo "========================================="
echo ""
echo "下一步操作:"
echo "  1. 编辑配置: nano $WORK_DIR/.env"
echo "  2. 添加代理: nano $WORK_DIR/proxies.txt"
echo "  3. 测试运行: cd $WORK_DIR && python3 gpt.py --count 1 --threads 1"
echo "  4. 后台运行: systemctl --user enable openai-reg"
echo "              systemctl --user start openai-reg"
echo "  5. 查看日志: journalctl --user -u openai-reg -f"
echo ""
echo "查看 token: ls $WORK_DIR/tokens/"
echo "========================================="
